import time
import tkinter as tk
from PIL import ImageTk, Image


def animate_wine_images(image_canvas):
    """
    Animates the wine images in the given canvas by moving the image in the top-left corner of the canvas diagonally to the
    left and up for 100 steps.

    :param image_canvas: A tkinter Canvas object containing wine images.
    :type image_canvas: tkinter.Canvas
    :return: None
    :rtype: None
    """
    x, y = image_canvas.coords(image_canvas.find_all()[0])
    for i in range(1, 101):
        image_canvas.move(image_canvas.find_all()[0], -10, -10)
        time.sleep(0.001)
        image_canvas.update()
    image_canvas.grid_forget()


def animate_prisoner_image(prisoner_img, center_canvas, check, speed):
    """
    Animates the movement of a prisoner image across the canvas.

    :param prisoner_img: The PhotoImage object of the prisoner image.
    :type prisoner_img: PhotoImage
    :param center_canvas: The Canvas object of the center portion of the GUI.
    :type center_canvas: Canvas
    :param check: An integer that indicates whether the prisoner is poisoned (1) or not (0).
    :type check: int
    :param speed: An integer that indicates the speed of the animation.
    :type speed: int
    :return: None.
    :rtype: None.
    """
    x = 100
    while x < 500:
        center_canvas.coords(prisoner_img, x, 350)
        x += 5
        time.sleep(0.1/speed)
        center_canvas.update()
    time.sleep(0.5)
    animate_wine_drinking(center_canvas, prisoner_img, check, speed)


def animate_wine_drinking(center_canvas, prisoner_img, check, speed):
    """
    Animates the drinking of wine by replacing the prisoner image with a sequence of images
    of spilled wine, followed by images of the prisoner drinking wine.

    Args:
        center_canvas (Canvas): The canvas on which the animation will be displayed.
        prisoner_img (int): The ID of the prisoner image on the canvas.
        check (int): An integer that determines whether the prisoner will die after drinking wine.
        speed (int): An integer that indicates the speed of the animation.

    Returns:
        None

    Raises:
        None

    """
    # load and resize the 4 images
    wine1 = Image.open("spilling1.png").resize((100, 100))
    wine2 = Image.open("spilling2.png").resize((100, 100))
    wine3 = Image.open("spilling3.png").resize((100, 100))
    wine4 = Image.open("spilling4.png").resize((100, 100))

    # create PhotoImage objects
    wine1_img = ImageTk.PhotoImage(wine1)
    wine2_img = ImageTk.PhotoImage(wine2)
    wine3_img = ImageTk.PhotoImage(wine3)
    wine4_img = ImageTk.PhotoImage(wine4)

    # create image objects on the canvas
    wine_images = [wine1_img, wine2_img, wine3_img, wine4_img]
    wine_image_ids = []
    for i in range(len(wine_images)):
        wine_image = center_canvas.create_image(550, 250, image=wine_images[i])
        wine_image_ids.append(wine_image)
        center_canvas.update()
        time.sleep(0.5/speed)
        center_canvas.delete(wine_image)

    # replace the prisoner image with a drinking images
    drinking_img = Image.open("PrisonerPreDrinking.png").resize((100, 200))
    drinking_photo_img = ImageTk.PhotoImage(drinking_img)
    center_canvas.itemconfigure(prisoner_img, image=drinking_photo_img)
    center_canvas.update()
    time.sleep(0.0001)

    drinking_img = Image.open("PrisonerDrinking.png").resize((100, 200))
    drinking_photo_img = ImageTk.PhotoImage(drinking_img)
    center_canvas.itemconfigure(prisoner_img, image=drinking_photo_img)
    center_canvas.update()
    time.sleep(1)

    # check the integer and replace the prisoner image accordingly
    if check == 1:
        prisoner_img2 = Image.open("DeadPrisoner.png").resize((100, 200))
        prisoner_photo_img2 = ImageTk.PhotoImage(prisoner_img2)
        center_canvas.itemconfigure(prisoner_img, image=prisoner_photo_img2)
        center_canvas.update()
        time.sleep(1)

    # clear the wine images from the canvas
    clear_canvas_elements(center_canvas, wine_image_ids)


def clear_canvas_elements(center_canvas, canvas_elements_ids):
    """
    Deletes the specified canvas elements from the given canvas.

    Args:
        center_canvas (Canvas): The canvas on which the elements to be deleted are located.
        canvas_elements_ids (list): A list of IDs of the canvas elements to be deleted.

    Returns:
        None

    Raises:
        None

    """
    # delete the canvas elements
    for id in canvas_elements_ids:
        center_canvas.delete(id)


class Screen:
    def __init__(self):
        self.number_matrix = None
        self.instruction_label = None
        self.result_label = None
        self.image_canvas = None
        self.slave_canvas = None
        self.number_canvas = None
        self.slave_photo_img = None
        self.photo_img = None
        self.slave_img = None
        self.img = None

    def show_matrix_on_screen(self, center_canvas, matrix, check, speed):
        """
          Display a matrix on the center_canvas object along with a scrollbar and some images.

          :param center_canvas: A tkinter.Canvas object where the matrix will be displayed.
          :type center_canvas: tkinter.Canvas
          :param matrix: A two-dimensional list representing the matrix to be displayed.
          :type matrix: list[list[int]]
          :param check: A boolean value indicating whether to animate the prisoner image or not.
          :type check: bool
          :param speed: An integer that indicates the speed of the animation.
          :type speed: int
          :return: None
          :rtype: None
          """
        canvas_elements_ids = []
        # create Canvas object for the slave image
        self.slave_img = Image.open("Prisoner.png").resize((100, 200))
        self.slave_photo_img = ImageTk.PhotoImage(self.slave_img)
        self.img = Image.open("King.png")
        self.img = self.img.resize((300, 400))
        self.photo_img = ImageTk.PhotoImage(self.img)  # store a reference to the PhotoImage object
        prisoner = center_canvas.create_image(100, 350, image=self.slave_photo_img)
        canvas_elements_ids.append(prisoner)
        king = center_canvas.create_image(300, 350, image=self.photo_img)
        canvas_elements_ids.append(king)

        # create a Canvas object to hold the matrix frame and the scrollbar
        matrix_canvas = tk.Canvas(center_canvas)
        matrix_canvas.place(relx=0.80, rely=0.5, anchor='center')

        # create a scrollbar for the vertical axis
        v_scrollbar = tk.Scrollbar(center_canvas, width=10, relief='raised', borderwidth=2)
        v_scrollbar.place(relx=0.99, rely=0.5,
                          relheight=matrix_canvas.winfo_reqheight() / matrix_canvas.winfo_height() / 1000,
                          anchor='center')

        # create a scrollbar for the horizontal axis
        h_scrollbar = tk.Scrollbar(center_canvas, orient=tk.HORIZONTAL, width=10, relief='raised', borderwidth=2)
        h_scrollbar.place(relx=0.80, rely=0.71,
                          relwidth=matrix_canvas.winfo_reqwidth() / matrix_canvas.winfo_width() / 1500, anchor='center')

        # configure the vertical scrollbar and the Canvas object
        matrix_canvas.config(yscrollcommand=v_scrollbar.set, bg="#cd7c2a")
        v_scrollbar.config(command=matrix_canvas.yview)

        # configure the horizontal scrollbar and the Canvas object
        matrix_canvas.config(xscrollcommand=h_scrollbar.set)
        h_scrollbar.config(command=matrix_canvas.xview)

        # create a new frame to hold the matrix elements
        matrix_elements_frame = tk.Frame(matrix_canvas)
        matrix_elements_frame.config(bg="#cd7c2a")
        for i in range(len(matrix)):
            for j in range(len(matrix[i])):
                if matrix[i][j] != 0:
                    # create text for the number
                    number_text = str(matrix[i][j])
                    matrix_elements_frame.columnconfigure(j, weight=1)
                    matrix_elements_frame.rowconfigure(i, weight=1)
                    number_label = tk.Label(matrix_elements_frame, text=number_text, font=("Cooper Black", 12),
                                            bg="#cd7c2a", fg="#ffffff")
                    number_label.grid(row=i, column=j, padx=5, pady=5)

        # add the matrix elements frame to the matrix Canvas object
        matrix_canvas.create_window((0, 0), window=matrix_elements_frame, anchor="nw")

        # configure the matrix Canvas object
        matrix_elements_frame.update_idletasks()
        matrix_canvas.config(scrollregion=matrix_canvas.bbox("all"))

        prison2 = center_canvas.create_image(100, 350, image=self.slave_photo_img)
        canvas_elements_ids.append(prison2)

        # animate the prisoner image
        animate_prisoner_image(prison2, center_canvas, check, speed)
        clear_canvas_elements(center_canvas, canvas_elements_ids)
        matrix_canvas.place_forget()
        v_scrollbar.place_forget()
        h_scrollbar.place_forget()

    def show_puzzle_solution(self, number):
        """
        Presents the solution to the poison puzzle game.

        :param number: The number representing the poisoned wine bottle.
        :type number: int

        :return: None

        :rtype: None
        """
        # Present puzzle solution
        self.instruction_label.config(
            text=f"{min(self.number_matrix.m, 10)} questions were asked, wine bottle number {number} had been poisoned")
        self.instruction_label.place(relx=0.5, rely=0.2, anchor='center')

        # Convert number to binary and put it into an array
        binary_array = [int(x) for x in bin(number)[2:].zfill(8)]
        self.result_label.place(relx=0.5, rely=0.5, anchor='center')
        # position the Label object in the center of the screen
        self.result_label.grid_rowconfigure(0, weight=1)  # configure row 0 to expand vertically
        self.result_label.grid_columnconfigure(0, weight=1)  # configure column 0 to expand horizontally

        # Load and resize slave and wine images
        slave_img = Image.open("Prisoner.png").resize((100, 200))
        poisoned_slave_img = Image.open("DeadPrisoner.png").resize((100, 200))
        poisoned_wine_img = Image.open("PoisonedWineJug.png").resize((80, 100))
        poisoned_wine_photo_img = ImageTk.PhotoImage(poisoned_wine_img)
        wine_img = Image.open("WineJug.png").resize((80, 100))
        wine_photo_img = ImageTk.PhotoImage(wine_img)
        # Create labels for each slave and wine image and add them to the result label
        num_slaves_killed = 0
        total_slaves = 0
        for i, binary_digit in enumerate(binary_array):
            if binary_digit == 1:
                # Add poison_wine label above poisoned_slave label
                wine_label = tk.Label(self.result_label, image=poisoned_wine_photo_img, bg="#cd7c2a")
                wine_label.image = poisoned_wine_photo_img
                wine_label.grid(row=3, column=i, sticky="NSEW")

                img = poisoned_slave_img
                num_slaves_killed += 1
            else:
                wine_label = tk.Label(self.result_label, image=wine_photo_img, bg="#cd7c2a")
                wine_label.image = wine_photo_img
                wine_label.grid(row=3, column=i, sticky="NSEW")
                img = slave_img

            total_slaves += 1
            photo_img = ImageTk.PhotoImage(img)
            label = tk.Label(self.result_label, image=photo_img, bg="#cd7c2a")
            label.image = photo_img
            label.grid(row=4, column=i, sticky="NSEW")  # position in the middle row

            # show binary representation beneath each prison
            binary_label = tk.Label(self.result_label, text=str(binary_digit), font=("Cooper Black", 17), fg="#7d1010",
                                    bg="#cd7c2a")
            binary_label.grid(row=5, column=i, sticky="NSEW")

        # Add label for number of slaves killed
        if num_slaves_killed == 1:
            temp = str(num_slaves_killed) + " slave was killed\n"
        else:
            temp = str(num_slaves_killed) + " slaves were killed\n"
        if total_slaves <= 8:
            num_slaves_killed_label = tk.Label(self.result_label, text=temp, font=("Cooper Black", 17), fg="#7d1010", bg="#cd7c2a", padx=300)
        else:
            num_slaves_killed_label = tk.Label(self.result_label, text=temp, font=("Cooper Black", 17), fg="#7d1010", bg="#cd7c2a", padx=380)
        num_slaves_killed_label.grid(row=6, columnspan=len(binary_array))
