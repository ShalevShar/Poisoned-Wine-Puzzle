import math
from screen import Screen


class NumberMatrix:

    def __init__(self, n):
        """
        Initialize a matrix of size n x n using a memory-efficient data structure.

        :param n: The size of the matrix. Must be a positive integer.
        :type n: int
        :raises TypeError: If n is not an integer.
        :raises ValueError: If n is not a positive integer.

        :return: None

        :rtype: NoneType
        """
        self.n = n
        self.m = int(math.log(n, 2) + 1)
        self.p = int(math.sqrt(int(n // 2) + 1)) + 1
        self.matrix = [[[0 for x in range(self.p)]
                        for y in range(self.p)]
                       for z in range(self.m)]
        self.available_cells = {i: [(r, c) for r in range(self.p) for c in range(self.p)]
                                for i in range(self.p * 2)}

        for i in range(1, n + 1):
            sf = bin(i)[2:]
            sr = sf[::-1]
            t = 0
            for j in sr:
                if j == "1":
                    r, c = self.available_cells[t].pop(0)
                    self.matrix[t][r][c] = i
                t += 1

    def get_numbers_in_matrix(self, canvas, result_label, i, poisoned, speed):
        """
         Retrieves a list of numbers that are present in the matrix for a given layer 'i'.
         If the 'poisoned' number is present in the list, 'check' is set to 1, otherwise to 0.
         Displays the matrix on the screen with the poisoned number highlighted.

         :param canvas: A tkinter canvas object on which to draw the matrix.
         :type canvas: object

         :param result_label: A tkinter label object on which to display the matrix.
         :type result_label: object

         :param i: The index of the matrix layer to retrieve the numbers from.
         :type i: int

         :param poisoned: The number to highlight in the matrix if it is present.
         :type poisoned: int

         :param speed: An integer that indicates the speed of the animation.
         :type speed: int

         :return: A list of numbers present in the matrix layer.
         :rtype: list[int]
         """
        numbers = []
        for j in range(len(self.matrix[i])):
            for k in range(len(self.matrix[i][j])):
                if self.matrix[i][j][k] != 0:
                    numbers.append(self.matrix[i][j][k])
        if poisoned in numbers:
            check = 1
        else:
            check = 0
        Screen.show_matrix_on_screen(result_label, canvas, self.matrix[i], check, speed)
        return numbers
