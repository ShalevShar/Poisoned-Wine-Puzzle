import random
import tkinter as tk
from screen import Screen
from numberMatrix import NumberMatrix
from PIL import ImageTk, Image
import pyglet


class GuessNumberGame:
    def __init__(self):
        """
        Initializes a Poisoned Wine Puzzle GUI.

        :return: None
        :rtype: None

        :param self: An instance of the Poisoned Wine Puzzle GUI.
        :type self: PoisonedWinePuzzleGUI
        """
        self.root = None  # The root Tkinter window
        self.background_label = None  # The background image label
        self.center_canvas = None  # The canvas where the wine glasses are drawn
        self.number_matrix = None  # The matrix representing the wine glasses
        self.question_label = None  # The label that displays the question
        self.instruction_label = None  # The label that displays the instructions
        self.result_label = None  # The label that displays the result
        self.yes_button = None  # The "Yes" button
        self.no_button = None  # The "No" button
        self.start_button = None  # The "Start" button
        self.bottles_entry = None  # The entry for the number of wine bottles
        self.poisoned_entry = None  # The entry for the poisoned wine bottle number
        self.answer = None  # The answer to the puzzle
        self.error_label = None  # The label that displays errors
        self.poisoned_label = None  # The label that displays the poisoned wine bottle number
        self.computer_mode_slider = None  # The slider for selecting computer mode
        self.play_again_button = None  # The "Play Again" button
        self.exit_button = None  # The "Exit" button
        self.isComputerMode = False  # Flag for computer mode
        self.computer_mode_var = 0  # The value of the computer mode slider
        self.poisoned_bottle = 0  # The poisoned bottle number
        self.computer_poisoned_entry = None  # The label that displays the poisoned wine bottle chosen by the computer
        self.speed_mode_slider = 0  # The value of the game speed

    def start_game(self):
        """
        Starts the Poisoned Wine Puzzle game and initializes the game state.

        :return: None
        :rtype: None

        :param self: An instance of the Poisoned Wine Puzzle GUI.
        :type self: PoisonedWinePuzzleGUI
        """
        self.start_button.place_forget()  # Hide the start button
        self.number_matrix = NumberMatrix(int(self.bottles_entry.get()))  # Initialize the wine glass matrix
        self.question_label.place_forget()  # Hide the question label
        self.poisoned_label.place_forget()  # Hide the poisoned bottle label
        self.poisoned_entry.place_forget()  # Hide the poisoned bottle entry
        self.instruction_label.place_forget()  # Hide the instruction label
        self.bottles_entry.place_forget()  # Hide the wine bottle entry
        self.yes_button.config(command=lambda: self.set_answer(1))  # Configure the "Yes" button
        self.no_button.config(command=lambda: self.set_answer(0))  # Configure the "No" button
        self.computer_mode_slider.place_forget()  # Hide the computer mode slider
        self.computer_poisoned_entry.place_forget()  # Hide the computer poisoned bottle selection
        self.speed_mode_slider.place_forget()  # Hide the speed slider

        # Determine the poisoned bottle number
        if not self.isComputerMode:
            self.poisoned_bottle = int(self.poisoned_entry.get())

        # Ask questions to determine the poisoned bottle
        number = 0
        addition_number = 0
        next_slave = 1
        for i in range(min(self.number_matrix.m, 10)):
            addition_number = self.ask_question(i, next_slave, self.poisoned_bottle)
            number += addition_number
            if addition_number > 0:
                next_slave += 1
            addition_number = 0

        # Clear the result_label widget before showing the wine image
        for widget in self.result_label.winfo_children():
            widget.destroy()

        self.question_label.place_forget()  # Hide the question label
        self.yes_button.place_forget()  # Hide the "Yes" button
        self.no_button.place_forget()  # Hide the "No" button

        # Show the solution to the puzzle
        Screen.show_puzzle_solution(self, number)

        # Show the "Play Again" button
        self.play_again_button.place(relx=0.5, rely=0.8, anchor='center')

    def ask_question(self, i, next_slave, poisoned_bottle):
        """
          Asks a question to determine if the poisoned bottle is in a given set.

          :param next_slave: An integer indicating the number of the slave
          :param i: An integer value indicating the number of bottles set.
          :type i: int
          :param poisoned_bottle: An integer value indicating the bottle number of the poisoned bottle.
          :type poisoned_bottle: int

          :return: An integer value indicating the result of the question. If the answer is "yes", the value will be 2 to the power of i. If the answer is "no", the value will be 0.
          :rtype: int
          """
        # Clear the result_label widget before drawing the new labels and images
        for widget in self.result_label.winfo_children():
            widget.destroy()

        self.answer = None
        self.question_label.config(text=f"Slave number {next_slave}")
        self.question_label.place(relx=0.5, rely=0.2, anchor='center')
        speed = self.speed_mode_slider.get()
        all_nums = NumberMatrix.get_numbers_in_matrix(self.number_matrix, self.center_canvas, self.result_label, i, poisoned_bottle, speed)

        # Update GUI
        self.root.update()
        # root.update_idletasks()

        # If the poisoned bottle is in the current set, press "yes"
        # Otherwise, press "no"
        if poisoned_bottle in all_nums:
            self.yes_button.invoke()
            self.answer = 1
        else:
            self.no_button.invoke()
            self.answer = 0

        while self.answer is None:
            self.root.update()

        if self.answer == 1:
            return 2 ** i
        else:
            return 0

    def set_answer(self, value):
        """
        Sets the answer attribute to the given value.

        :param value: An integer representing the answer to the current question (1 for "Yes" and 0 for "No").
        :return: None
        """
        self.answer = value

    def validate_input(self):
        """
        Validates the input values entered by the user and displays an error message if any of the values are invalid.
        If the input is valid, it calls the `start_game` function to begin the game.

        :param: None
        :return: None
        """
        check = 0
        num_bottles = 0
        try:
            self.error_label.grid(row=3, column=0, columnspan=2)
            check = 2
            temp_bottles = self.bottles_entry.get()
            temp_poison = self.poisoned_entry.get()
            if temp_bottles and not temp_bottles.isdigit():
                check = 3
                raise ValueError
            num_bottles = int(temp_bottles)
            if not self.isComputerMode:
                if temp_poison and not temp_poison.isdigit():
                    check = 3
                    raise ValueError
                poisoned_bottle = int(temp_poison)
                if poisoned_bottle > num_bottles or poisoned_bottle < 1:
                    check = 0
                    raise ValueError
            if num_bottles < 1 or num_bottles > 1000:
                check = 1
                raise ValueError
            self.error_label.config(text="")
            self.start_game()
        except ValueError:
            if check == 3:
                self.error_label.config(text="Invalid input. Enter digits only")
            elif check == 1:
                self.error_label.config(text="Number of bottles should be between 1-1000")
            elif check == 0:
                self.error_label.config(text=f"Poisoned bottle should be between 1-{num_bottles}")
            else:
                self.error_label.config(text="One or more fields are empty")

            self.error_label.place(relx=0.5, rely=0.4, anchor='center')

    def make_random_poison(self):
        """
           Generates a random poisoned bottle number and stores it in self.poisoned_bottle.

           :param self: The object instance.
           :type self: object
           :return: None
           """
        num_bottles = int(self.bottles_entry.get())
        self.poisoned_bottle = int(random.randint(1, num_bottles))

    def computer_mode(self, value):
        """
        Toggles the computer mode for the game.

        :param value: An integer value indicating the desired mode. If the value is 1, the computer mode is turned on. If the value is not 1, the computer mode is turned off.
        :type value: int

        :return: None

        :rtype: None
        """
        if value == 1:
            try:
                num_of_bottles = int(self.bottles_entry.get())
                if not num_of_bottles:
                    raise ValueError
                else:
                    self.poisoned_entry.place_forget()
                    self.isComputerMode = True
                    self.make_random_poison()
                    self.computer_poisoned_entry.config(text=f"{self.poisoned_bottle}")
                    self.computer_poisoned_entry.place(relx=0.564, rely=0.5, anchor='center')
            except ValueError:
                self.computer_mode_slider.set(0)
                self.error_label.config(text="No Amount of bottles has been set")
                self.error_label.place(relx=0.5, rely=0.4, anchor='center')

        else:
            self.poisoned_entry.place(relx=0.6, rely=0.5, anchor='center')
            self.isComputerMode = False
            self.error_label.place_forget()
            self.computer_poisoned_entry.place_forget()

    def manual_mode(self, value):
        """
        Controls the manual mode of the game.

        :param value: A boolean value indicating whether manual mode is active or not.
        :type value: bool

        :return: None
        :rtype: None
        """
        if value:
            self.computer_mode_slider.place_forget()
            self.poisoned_entry.place_forget()
        else:
            self.computer_mode_slider.place(relx=0.5, rely=0.6, anchor='center')
            self.poisoned_entry.place(relx=0.6, rely=0.5, anchor='center')

    def back_to_main_screen(self):
        """
        Resets the game to the main screen by hiding various widgets and resetting their values.

        :return: None
        :rtype: None
        """
        self.instruction_label.config(text="Bottles Amount (1-1000)")
        self.instruction_label.place(relx=0.4, rely=0.3, anchor='center')
        self.bottles_entry.place(relx=0.6, rely=0.3, anchor='center')
        self.error_label.place_forget()
        self.poisoned_label.place(relx=0.4, rely=0.5, anchor='center')
        self.computer_mode_slider.place(relx=0.5, rely=0.6, anchor='center')
        self.computer_mode_slider.set(0)
        self.speed_mode_slider.place(relx=0.5, rely=0.7, anchor='center')
        self.speed_mode_slider.set(0)
        self.poisoned_entry.place(relx=0.6, rely=0.5, anchor='center')
        self.result_label.config(text="")
        self.result_label.place_forget()
        #self.result_label.place(relx=0.5, rely=0.8, anchor='center')
        self.bottles_entry.delete(0, tk.END)
        self.poisoned_entry.delete(0, tk.END)
        self.play_again_button.place_forget()
        #self.start_button.config(command=self.validate_input())
        self.start_button.place(relx=0.5, rely=0.8, anchor='center')
        self.exit_button.place(relx=0.5, rely=0.9, anchor='center')


if __name__ == '__main__':
    """
    This function is the main function of the game. It creates an instance of GuessNumberGame class and sets up the GUI
    for the game by creating labels, buttons, and entry widgets using tkinter. It also defines several callbacks for
    the buttons and sliders.

    :return: None
    :rtype: None
    """
    game = GuessNumberGame()

    # GUI setup
    game.root = tk.Tk()
    game.root.config(bg='')
    game.root.geometry("1050x700")
    game.root.title("POISONED BOTTLE PUZZLE")

    # Set background image
    background_image = tk.PhotoImage(file="background.png")
    game.background_label = tk.Label(game.root, image=background_image)
    game.background_label.place(x=0, y=0, relwidth=1, relheight=1)

    pyglet.font.add_file("PineappleDemo.ttf")

    game.center_canvas = tk.Canvas(game.root, width=1050, height=700)
    game.center_canvas.place(relx=0.5, rely=0.5, anchor='center')
    game.center_canvas.create_image(0, 0, image=background_image, anchor="nw")
    game.center_canvas.pack(fill=tk.BOTH, expand=1)

    header_text = game.center_canvas.create_text(520, 65, text="POISONED BOTTLE PUZZLE", font=("Cooper Black", 50),
                                                 fill='#ffffff', anchor='center')

    game.question_label = tk.Label(game.center_canvas, text="", font=("Cooper Black", 16), fg="#ffffff", bg='#cd7c2a')
    game.question_label.place(relx=0.5, rely=0.2, anchor='center')
    game.question_label.pack_forget()

    game.instruction_label = tk.Label(game.center_canvas, text="Bottles Amount (1-1000)",
                                      font=("Cooper Black", 15, "bold"), bg='#cd7c2a', fg="#ffffff")
    game.instruction_label.place(relx=0.4, rely=0.3, anchor='center')

    game.bottles_entry = tk.Entry(game.center_canvas, font=("Cooper Black", 14), fg='#5F264A', width=10, bg='#cd7c2a')
    game.bottles_entry.place(relx=0.6, rely=0.3, anchor='center')

    game.error_label = tk.Label(game.center_canvas, text="", font=("Cooper Black", 14), bg='#cd7c2a', fg="#8b0808",
                                )
    game.error_label.place(relx=0.5, rely=0.4, anchor='center')

    game.poisoned_label = tk.Label(game.center_canvas, text="Poisoned Bottle", font=("Cooper Black", 15, "bold"),
                                   bg='#cd7c2a',
                                   fg="#ffffff")
    game.poisoned_label.place(relx=0.4, rely=0.5, anchor='center')

    computer_mode_var = tk.IntVar()

    game.computer_mode_slider = tk.Scale(game.center_canvas, from_=1, to=0, showvalue=False, orient='horizontal',
                                         length=260, width=15, sliderrelief="flat",
                                         font=("Cooper Black", 15, 'bold'), bg='#cd7c2a',
                                         highlightthickness=0, sliderlength=130,
                                         troughcolor="#965512", activebackground="#e0e0e0", fg="#ffffff",
                                         variable=computer_mode_var, resolution=1, label="Computer        Human",
                                         command=lambda x: game.computer_mode(computer_mode_var.get()))
    game.computer_mode_slider.place(relx=0.5, rely=0.6, anchor='center')

    game.computer_mode_slider.set(0)

    game.poisoned_entry = tk.Entry(game.center_canvas, font=("Cooper Black", 14), fg='#5F264A', bg='#cd7c2a', width=10)
    game.poisoned_entry.place(relx=0.6, rely=0.5, anchor='center')

    game.computer_poisoned_entry = tk.Label(game.center_canvas, text="", fg="#5F264A", font=("Cooper Black", 15, "bold"), bg='#cd7c2a')
    game.computer_poisoned_entry.place(relx=0.564, rely=0.5, anchor='center')
    game.computer_poisoned_entry.place_forget()

    speed_mode_var = tk.IntVar()

    game.speed_mode_slider = tk.Scale(game.center_canvas, from_=1, to=10, orient='horizontal',
                                         length=265, width=5,
                                         font=("Cooper Black", 15, 'bold'), bg='#cd7c2a',
                                         highlightthickness=0, sliderlength=30,
                                         troughcolor="#965512", activebackground="#e0e0e0", fg="#ffffff",
                                         variable=speed_mode_var, resolution=1, label="L         <  Speed  <        H", sliderrelief="flat")
    game.speed_mode_slider.place(relx=0.5, rely=0.7, anchor='center')

    game.result_label = tk.Label(game.center_canvas, text="", font=("Cooper Black", 14), bg='#cd7c2a')
    game.result_label.place(relx=0.5, rely=0.5, anchor='center')
    game.result_label.config(bg="#e0e0e0")
    game.result_label.place_forget()

    game.yes_button = tk.Button(game.center_canvas, text="Yes", font=("Cooper Black", 14), fg="#5F264A", bg='#cd7c2a')
    game.yes_button.place(relx=0.4, rely=0.8, anchor='center')
    game.yes_button.place_forget()

    game.no_button = tk.Button(game.center_canvas, text="No", font=("Cooper Black", 14), fg="#5F264A", bg='#cd7c2a')
    game.no_button.place(relx=0.6, rely=0.8, anchor='center')
    game.no_button.place_forget()

    game.start_button = tk.Button(game.center_canvas, text="Start Game", font=("Cooper Black", 14), fg="#5F264A",
                                  command=game.validate_input)
    game.start_button.place(relx=0.5, rely=0.8, anchor='center')

    game.play_again_button = tk.Button(game.center_canvas, text="Play Again",
                                       font=("Cooper Black", 14), fg="#5F264A", command=game.back_to_main_screen)
    game.play_again_button.pack_forget()

    game.exit_button = tk.Button(game.center_canvas, text='Exit', font=("Cooper Black", 14), fg="#5F264A", command=game.root.destroy)
    game.exit_button.place(relx=0.5, rely=0.9, anchor='center')

    game.root.mainloop()
